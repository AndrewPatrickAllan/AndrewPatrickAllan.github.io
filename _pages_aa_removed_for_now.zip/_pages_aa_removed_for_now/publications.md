---
layout: page
permalink: /publications/
title: publications
description: 
nav: true
nav_order: 2
---

<!-- _pages/publications.md -->
<div class="publications">
<h1> First author publications </h1>

{% bibliography %}

<h1> Collaborative publications </h1>

{% bibliography -f contrib_articles %}

</div>
